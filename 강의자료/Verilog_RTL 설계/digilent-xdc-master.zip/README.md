# digilent-xdc
A collection of Master XDC files for Digilent FPGA and Zynq boards. 

Documentation for these boards, including schematics and reference manuals, can be found through the [Programmable Logic](https://digilent.com/reference/programmable-logic/start) landing page on the  Digilent Reference site.