Put the all directory CD4000 in "LTspiceIV\lib\sym\CD4000"
Copy files CD4066B.lib, CD4000.lib and CD4066.sub into "LTspiceIV\lib\sub\" directory.
